/*
 * Christian Sherland
 * 12-1-13
 * ECE 357 - Problem Set 9
 *
 * sched.h
 *  Header file for the scheduler
 *
 */

#ifndef SCHED_H
#define SCHED_H

#include "savectx.h"

#define SCHED_NPROC     511  // (maximum pid)-1
#define SCHED_READY     0
#define SCHED_RUNNING   1
#define SCHED_SLEEPING  2
#define SCHED_ZOMBIE    -1
#define STACK_SIZE      65536

/* 
 * struct sched_proc
 *  Describes a simulated task.
 */
struct sched_proc {
    int nice;               // Nice Value (int in [-20,19])
    int priority;           // Static priority (int in [0, 39])
    int state;              // Current state of proc
    int code;               // Exit code
    int accumulated;        // Accumulated processing time total
    int cpu_time;           // cpu_time currently running
    int allocated;          // Allocated process time
    int pid;                // Processes ID #
    int ppid;               // PID of parent
    void *stack;            // Where the stack is
    struct savectx context; // To restore registers
};

/*
 * struct sched_waitq
 */
struct sched_waitq {
    struct sched_proc *procs[SCHED_NPROC];
    int n_procs;
};

/* 
 * void sched_init(void (*init_fn)())
 *  Initialized a test scheduling system, including setting up
 *  a periodic interval timer (see setitimer), establishing a 
 *  sched_tick as the signal handler for that timer and creating
 *  the initial task which will have a pid of 1.
 *
 *  After doing so, it makes pid 1 runnable and transfers 
 *  execution to it (including switching to its stack) at the
 *  location init_fn. 
 *
 *  This function is not expected to return and if it does, it
 *  is OK to have unpredictable results.
 */
void sched_init(void (*init_fn)());

/*
 * void sched_fork()
 *  Create a new simulated task which is a copy of the caller.
 *  Allocate a new pid for the child, and make the child runnable
 *  and eligible to be scheduled. 
 *
 *  It's not required that the relative order of parent vs.
 *  child being scheduled be defined.
 *
 *  Unlike the real fork, does no duplicate the entire address
 *  space. Parent and child will execute in the same address
 *  space. However, it does create a new private stack area
 *  for the child and initializes it to be a copy of the parent's
 *
 *  Returns:
 *      0       - to the child
 *      new_pid - to the parent
 *      -1      - on error
 */
int sched_fork();

/*
 * void sched_exit(int code)
 *  Terminate the current task, making it a ZOMBIE, and store
 *  the exit code. If a parent is sleeping in the sched_wait(),
 *  wake it up and return the exit code to it.
 *
 *  This is not equivalent to SIGCHLD implemented. sched_exit()
 *  will not return. Another runnable process will be scheduled.
 */
void sched_exit(int code);

/*
 * void sched_wait(int *exit_code)
 *  Return the exit code of a zombie child and free the
 *  resources of that child.  
 *
 *  If there is more than one such child, the order in which 
 *  the codes are returned is not defined. If there are no 
 *  zombie children, but the caller does have at least one 
 *  child, place the caller in SLEEPING, to be woken up when 
 *  a child calls sched_exit().   
 *
 *  Since there are no simulated signals, the exit code
 *  is simply the integer from sched_exit().
 *
 *  Return:
 *      -1  - if no children
 *       0  - otherwise
 */
int sched_wait(int *exit_code);

/* 
 * void sched_nice(int niceval)
 *  Set the current task's "nice value" to the specified
 *  niceval. 
 *
 *  Nice values may rant from +19 (least preferred) to -20
 *  (most preferred). Clamp any out-of-range values to those
 *  limits.
 */
void sched_nice(int niceval);

/*
 * int sched_getpid()
 *  Return current tasks PID
 */
int sched_getpid();

/*
 * int sched_getppid()
 *  Return pid of the current task's parent
 */
int sched_getppid();

/*
 * int sched_gettick()
 *  Return the number of ticks since startup
 */
int sched_gettick();

/* 
 * void sched_ps()
 *  Output to stdout a listing of all of the current tasks,
 *  including sleeping and zombie tasks.  Lists the following 
 *  information in tabular form:
 *         pid
 *         ppid
 *         current state
 *         base addr of private stack area
 *  if SLEEPING, 
 *         address of wait queue
 *         static priority
 *         dynamic priority
 *         total CPU time used (in ticks)
 *
 *  Should establish sched_ps() as the signal handler for 
 *  SIGABRT so that a ps can be forced at anytime by sending 
 *  the testbed SIGABRT  
 */
void sched_ps();

/* 
 * void sched_switch()
 *  Should be the sole place where a context switch is made,
 *  analogous to schedule() within the Linux kernel.
 * 
 *  sched_switch() places the current task on the run queue
 *  (assuming it is READY), then select the best READY task 
 *  from the runqueue, taking into account the dynamic priority
 *  of each task.  The selected task should then be placed
 *  in the RUNNING state and a context switch made to it
 *  (unless, of course, the best task is also the current task)
 */
void sched_switch();

/* 
 * void sched_tick()
 *  The signal handler for SIGVTALRM signal generated by the
 *  periodic timer. Each occurrence of the timer signal is 
 *  considered a tick.
 * 
 *  Examines the currently running task and if its time
 *  slice has just expired, marks that task as READY, places
 *  it on the run queue based on its current dynamic priority, 
 *  and then calls sched_switch() to cause a new task to be run
 *
 *  Watch out for signal mask issues. Remember SIGVTALRM will
 *  by default be masked on entry to your signal handler.
 */
void sched_tick();

#endif //SCHED_H